import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cts.hospitalmanagement.config.EHMSConfig;
import com.cts.hospitalmanagement.exception.NoDataFoundException;
import com.cts.hospitalmanagement.service.PatientManagementService;

/**
 *
 */

public class EHMSMain {

	/**
	 * @param args
	 * @throws NoDataFoundException
	 */
	public static void main(String[] args) throws NoDataFoundException {
		// TODO Auto-generated method stub

		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(
				EHMSConfig.class);

		PatientManagementService patientManagementService = applicationContext
				.getBean(PatientManagementService.class);

		patientManagementService.addPatientDetails(100, "ECG");

		patientManagementService.getBenefits("DENTAL");

	}

}
