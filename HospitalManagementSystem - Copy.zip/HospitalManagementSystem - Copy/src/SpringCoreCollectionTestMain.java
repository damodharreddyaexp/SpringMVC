import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.hospitalmanagement.core.HelloSpringCoreWorld;
import com.cts.hospitalmanagement.exception.NoDataFoundException;

/**
 *
 */

public class SpringCoreCollectionTestMain {

	/**
	 * @param args
	 * @throws NoDataFoundException
	 */
	public static void main(String[] args) throws NoDataFoundException {
		// TODO Auto-generated method stub
		/*ApplicationContext context = new ClassPathXmlApplicationContext(
				"springcoreapplicationcontext.xml");*/
		/*XmlBeanFactory context = new XmlBeanFactory
                (new ClassPathResource("springcoreapplicationcontext.xml"));*/
		AbstractApplicationContext context = 
                new ClassPathXmlApplicationContext("springcoreapplicationcontext.xml");
		// Is scope is set singleton spring core container creates exactly one instance of the object defined by that bean defination .
		// the singleton instance is stored in cache and all subsequent requests and references returned from the cache.
		HelloSpringCoreWorld objectA = (HelloSpringCoreWorld) context
				.getBean("helloWorldSpringCore");
		objectA.setMessage("Hi Damodhar");
		System.out.println("objectA.message" + objectA.getMessage());
		HelloSpringCoreWorld objectB = (HelloSpringCoreWorld) context
				.getBean("helloWorldSpringCore");
		System.out.println("objectB.getmessage::" + objectB.getMessage());
		context.registerShutdownHook();
		
		// if scop is set the prototype ,the spring container creates the new bean instance of the object evertime a request for that specific bean made.

	}

}
