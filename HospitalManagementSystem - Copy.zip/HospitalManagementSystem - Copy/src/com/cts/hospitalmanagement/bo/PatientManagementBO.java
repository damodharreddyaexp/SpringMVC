/**
 *
 */
package com.cts.hospitalmanagement.bo;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.hospitalmanagement.dao.PatientManagementDAO;
import com.cts.hospitalmanagement.exception.InvalidDataException;
import com.cts.hospitalmanagement.exception.NoDataFoundException;
import com.cts.hospitalmanagement.pojo.PatientVO;

@Component
public class PatientManagementBO {

	@Autowired
	private PatientManagementDAO patientManagementDAO;

	/*@Autowired
	MessageSource messageSource;*/

	@Resource(name = "diagnosticTest")
	Map<String, Float> diagnosticTestMap;

	/**
	 * @param employeeId
	 * @param transferLocation
	 * @throws EmployeeManagementException
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public void addPatientDetails(PatientVO patientVO)
			throws NoDataFoundException, InvalidDataException {
		Float testCost = getDiagnosticTestCost(patientVO.getTestName());
		patientVO.setTestCost(testCost);
		boolean isValid = patientManagementDAO.validPatient(patientVO.getPatientID());
		if(isValid)
		{
			patientManagementDAO.addPatientDetails(patientVO);
		}
	}

	/**
	 * @param transferLocation
	 * @return String
	 * @throws EmployeeManagementException
	 */
	public Float getDiagnosticTestCost(String testName)
			throws NoDataFoundException {
		float testCost;
		
		if(diagnosticTestMap.containsKey(testName)) 
		{
			testCost = diagnosticTestMap.get(testName);
		}
		else
		{
			throw new NoDataFoundException("No Such diagnostic Exists");
		}
		
		return testCost;

	}

}
