/**
 *
 */
package com.cts.hospitalmanagement.config;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ImportResource("classpath:applicationcontext.xml")
@PropertySource("classpath:mysql.properties")
@ComponentScan("com.cts.hospitalmanagement.bp,com.cts.hospitalmanagement.service,com.cts.hospitalmanagement.dao")
@EnableTransactionManagement
public class TestEHMSConfig {

	@Resource
	private static Environment env;

	public static DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl(env.getProperty("db.url"));
		dataSource.setUsername(env.getProperty("db.username"));
		dataSource.setPassword(env.getProperty("db.password"));
		return dataSource;
	}

	@Bean
	public static DataSourceTransactionManager getTransactionManager() {
		DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager();
		dataSourceTransactionManager.setDataSource(getDataSource());
		return dataSourceTransactionManager;
	}

	@Bean
	public static JdbcTemplate getJdbcTemplate(DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}

	@Bean
	public static MessageSource getMessageResource() {
		ResourceBundleMessageSource bundleMessageSource = new ResourceBundleMessageSource();
		bundleMessageSource.setBasename("benefits");
		return bundleMessageSource;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer getProperySource() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public Map<String, Float> diagnosticTest() {
		Map<String, Float> benefits = new HashMap<String, Float>();
		benefits.put("ECG", new Float(100));
		benefits.put("Angiogram", new Float(10000));
		benefits.put("BloodTest", new Float(70));
		return benefits;
	}

}
