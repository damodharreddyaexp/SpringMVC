/**
 *
 */
package com.cts.hospitalmanagement.constants;


public class SQLConstants {

	/**
	 *
	 */
	public static final String ADD_PATIENT_DETAILS = "INSERT INTO T_PATIENT_HEALTH_RECORDS values(?,?,?,?)";
	public static final String GET_PATIENT_RECORD="SELECT COUNT(PATIENT_ID) FROM T_PATIENT WHERE PATIENT_ID = ?";

}
