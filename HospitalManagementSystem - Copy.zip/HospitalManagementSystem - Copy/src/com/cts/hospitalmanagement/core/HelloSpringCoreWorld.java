package com.cts.hospitalmanagement.core;

public class HelloSpringCoreWorld {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void firstInit() {
		System.out.println("Bean is going through init.");
	}

	public void firstDestroy() {
		System.out.println("Bean will destroy now.");
	}
}
