package com.cts.hospitalmanagement.core;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class HelloSpringInjectingCollections {

	List addressList;
	Set addressSet;
	Map addressMap;
	Properties addressProp;

	public List getAddressList() {
		System.out.println("getAddressList::" + addressList);
		return addressList;
	}

	public void setAddressList(List addressList) {
		this.addressList = addressList;
	}

	public Set getAddressSet() {
		System.out.println("addressSet::" + addressSet);
		return addressSet;
	}

	public void setAddressSet(Set addressSet) {
		this.addressSet = addressSet;
	}

	public Map getAddressMap() {
		System.out.println("addressMap::" + addressMap);
		return addressMap;
	}

	public void setAddressMap(Map addressMap) {
		this.addressMap = addressMap;
	}

	public Properties getAddressProp() {
		System.out.println("addressProp::" + addressProp);
		return addressProp;
	}

	public void setAddressProp(Properties addressProp) {
		this.addressProp = addressProp;
	}

	public void firstInit() {
		System.out.println("Bean is going through init.");
	}

	public void firstDestroy() {
		System.out.println("Bean will destroy now.");
	}
}
