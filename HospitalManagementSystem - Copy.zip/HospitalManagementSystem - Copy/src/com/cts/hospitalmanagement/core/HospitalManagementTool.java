package com.cts.hospitalmanagement.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cts.hospitalmanagement.exception.PatientException;
import com.cts.hospitalmanagement.pojo.Patient;

public class HospitalManagementTool {
	public static void main(String[] args) {
		HospitalManagementTool hospitalManagementTool = new HospitalManagementTool();
		try {
			System.out
					.println(hospitalManagementTool
							.getPatientDetails("D:/Sample Java Exmples/RDP/HospitalManagementSystem/HospitalManagementSystem/src/HospitalInput.txt"));

			// System.out.println("ADCD123422**,,".matches("[A-Z]{4}[0-9]{4}(22).{4}"));
		} catch (PatientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private Map<Integer, Map> getPatientDetails(String filePath)
			throws PatientException {
		File file = new File(filePath);
		Map<Integer, Map> retMap = new HashMap<Integer, Map>();
		Map<String, List<Patient>> patientMap1 = new HashMap<String, List<Patient>>();
		Map<String, Integer> patientMap2 = new HashMap<String, Integer>();
		patientMap2.put("NEU", 0);
		patientMap2.put("GEN", 0);
		patientMap2.put("ENT", 0);
		List<Patient> patientList = new ArrayList<Patient>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		try {
			if (file.exists()) {
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line = null;
				while ((line = br.readLine()) != null) {
					Patient patient = new Patient();
					String[] strArray = line.split(",");
					if (strArray.length != 6) {
						throw new PatientException("invalid number of argument");
					}
					for (String str : strArray) {
						if (null == str || str.isEmpty()) {
							throw new PatientException("field is empty " + str);
						}
					}
					patient.setAdmissionDate(sdf.parse(strArray[4]));
					patient.setDischargeDate(sdf.parse(strArray[5]));
					if (patient.getAdmissionDate().after(
							patient.getDischargeDate())) {
						throw new PatientException(
								"discharge date should be greater than admission ");
					}
					if (strArray[0].matches("[a-zA-Z ]+")) {
						patient.setName(strArray[0]);
					} else {
						throw new PatientException("invalid name");
					}
					if (strArray[1].matches("((OUT)|(IN))[0-9]+")) {
						patient.setPatientCategory(strArray[1]);
					} else {
						throw new PatientException("invalid PatientPategory");

					}
					if (!strArray[2].isEmpty()) {
						patient.setGender(strArray[2]);
					} else {
						throw new PatientException("invalid gender");
					}
					if (strArray[3].matches("[0-9]{4}-((NEU)|(GEN)|(ENT))")) {
						patient.setPhysicianCategory(strArray[3]);
					} else {
						throw new PatientException("invalid Physician Category");

					}
					patientList.add(patient);
				}

				for (Patient patient : patientList) {
					int days = (int) (patient.getDischargeDate().getTime() - patient
							.getAdmissionDate().getTime())
							/ (1000 * 60 * 60 * 24);

					if (patient.getPhysicianCategory().endsWith("GEN")) {
						patient.setBill(days * 1250);
						patientMap2.put("GEN", patientMap2.get("GEN") + 1);
					}
					if (patient.getPhysicianCategory().endsWith("ENT")) {
						patient.setBill(days * 1500);
						patientMap2.put("ENT", patientMap2.get("ENT") + 1);
					}
					if (patient.getPhysicianCategory().endsWith("NEU")) {
						patient.setBill(days * 1750);
						patientMap2.put("NEU", patientMap2.get("NEU") + 1);
					}
					if (patientMap1.containsKey(sdf.format(patient
							.getAdmissionDate()))) {
						patientMap1.get(sdf.format(patient.getAdmissionDate()))
								.add(patient);
					} else {
						List list = new ArrayList<Patient>();
						list.add(patient);
						patientMap1.put(sdf.format(patient.getAdmissionDate()),
								list);
					}
				}
				retMap.put(1, patientMap1);
				retMap.put(2, patientMap2);
			}

		} catch (FileNotFoundException e) {
			throw new PatientException(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new PatientException(e);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			throw new PatientException(e);
		}
		return retMap;
	}
}
