package com.cts.hospitalmanagement.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*Note:The formula given to calculate NetPayment is not exactly same as from exam and it is easy calculation.
 * But only important is how to calculate loan period between end date and sanction date in months.
 LoantrustInsurance:
 return map --> Map<Integer,Map<String,List<LoanTrustVo>>>
 POLICYNUMBER   pannumber  startdate  period LoanRequestAmount Policyamt
 FST-1234-200000;FS123;    26/07/2017;48;400000;40000
 Policynumber = plocyType-policynumber-assuredsum
 validation
 all fileds should be mandatory
 policycode should be FSI/NRS
 policynuber should be non zero
 policynumber should be a number
 policyType should be FST or NRS
 policyamt should not be greater than assuredamt
 start date should be dd/MM/yyyy
 pan number should be start with FS and followd by three digit number
 key1
 //Not exactly from the exam requirement
 if policy Type FST  and request loan amt > 40% assuredsum  ELG
 if policy Type FST  and request loan amt > 60% assuredsum  NELG
 if policy Type NRS  and request loan amt > 60% assuredsum  ELG
 if policy Type NRS  and request loan amt > 60% assuredsum and < 70% policyamt ELG
 if policy Type NRS  and request loan amt > 60% assuredsum and > 70% policyamt NELG

 Map1("ELG",ELGlist)
 Map1("NELG",NELGlist) 

 if NELG then netpayment should be requestloan amt
 if ELG then netpayment should be calculate as follows
 Netpayment= caluculateassuredamt+interestamt

 caluculateassuredamt=assuredamt/period
 interestamt=(policyamt*1.2*loanperiod)/period

 loanperiod(have to calculate in months)=enddate-sanctiondate

 enddate=startdate+(period ----> given in months)
 Duplicate
 if policynumber is repeat then all the records should added in list

 Invalid
 if the loanrequest amt is greater than sumassured that that is invalid record


 Map2("DUP",dupilcatelist)
 Map2("INV",invalidlist)

 Output Map
 Map(1,Map1)
 Map(2,Map2)*/

/*
 FST-1234-200000;FS123;01/07/2016;48;400000;40000
 NRS-1234-200000;FS123;26/07/2016;48;400000;40000*/
public class Insurance {

	public static void main(String[] args) {

		Insurance insurance = new Insurance();
		try {
			System.out
					.println(insurance
							.loanTrustDetails(
									"D:/Sample Java Exmples/RDP/HospitalManagementSystem/HospitalManagementSystem/src/CreditCardInput.txt",
									"02/07/2017"));
		} catch (LoanTrustException e) {
			e.printStackTrace();
		}
	}

	public Map loanTrustDetails(String filePath, String sanctionDate)
			throws LoanTrustException {
		String line = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		Map<Integer, Map<String, List<LoanTrustVO>>> mainMap = new HashMap<Integer, Map<String, List<LoanTrustVO>>>();
		Map<String, List<LoanTrustVO>> innerMap1 = new HashMap<String, List<LoanTrustVO>>();
		Map<String, List<LoanTrustVO>> innerMap2 = new HashMap<String, List<LoanTrustVO>>();
		List<LoanTrustVO> loanTrustList = new ArrayList<LoanTrustVO>();
		File file = new File(filePath);
		if (!file.exists()) {
			throw new LoanTrustException("File should not be empty");
		}
		try {
			BufferedReader bf = new BufferedReader(new FileReader(file));
			while ((line = bf.readLine()) != null) {
				LoanTrustVO loanVO = new LoanTrustVO();
				String[] strArray = line.split(";");
				if (strArray.length != 6) {
					throw new LoanTrustException("All fields are mandatory");
				}

				for (String str : strArray) {
					if ((str.isEmpty()) || (str == null)) {
						throw new LoanTrustException("fields must not be blank");
					}
				}

				if (strArray[0].matches("((FST)|(NRS))[-][1-9]+[-][0-9]+")) {
					loanVO.setPolicyNumber(strArray[0]);
				} else {
					throw new LoanTrustException("inavlid policy number format");
				}

				String[] plcyNum = strArray[0].split("-");
				if (!plcyNum[0].matches("((FST)|(NRS))")) {
					throw new LoanTrustException("Invalid Policy Type");
				}
				if (!plcyNum[1].matches("[1-9]+")) {
					throw new LoanTrustException(
							"Policy number should be non zero");
				}
				if (plcyNum[1].matches("[a-zA-Z]+")) {
					throw new LoanTrustException(
							"policynumber should be a number");
				}

				float assuredAmount = Float.parseFloat(plcyNum[2]);

				if (Float.parseFloat(strArray[5]) > assuredAmount) {
					throw new LoanTrustException(
							"Policy amount should not be greater than assuredAmount");
				}

				Date startDt = sdf.parse(strArray[2]);
				loanVO.setStartDate(startDt);
				if (strArray[1].matches("(FS)[0-9]{3}")) {
					loanVO.setPanNumber(strArray[1]);
				} else {
					throw new LoanTrustException("Invalid PAN number");
				}

				Integer period = Integer.parseInt(strArray[3]);
				loanVO.setPeriod(period);
				Float loanAmount = Float.parseFloat(strArray[4]);
				loanVO.setLoanRequestAmount(loanAmount);
				Float policyAmount = Float.parseFloat(strArray[5]);
				loanVO.setPolicyAmount(policyAmount);

				loanTrustList.add(loanVO);
			}
			List<LoanTrustVO> elgList = new ArrayList<LoanTrustVO>();
			List<LoanTrustVO> nonElgList = new ArrayList<LoanTrustVO>();
			List<LoanTrustVO> dupList = new ArrayList<LoanTrustVO>();
			List<LoanTrustVO> inavlidList = new ArrayList<LoanTrustVO>();
			Map<Integer, LoanTrustVO> dupMap = new HashMap<Integer, LoanTrustVO>();
			for (LoanTrustVO loanVO : loanTrustList) {
				Calendar c = Calendar.getInstance();
				c.setTime(loanVO.getStartDate());
				c.add(Calendar.MONTH, loanVO.getPeriod());
				Date endDate = c.getTime();
				loanVO.setEndDate(endDate);
				String[] plcySplit = loanVO.getPolicyNumber().split("-");
				String plcyTyp = plcySplit[0];
				Integer plcyCode = Integer.parseInt(plcySplit[1]);
				Float assuredAmount = Float.parseFloat(plcySplit[2]);
				if (dupMap.containsKey(plcyCode)) {
					dupList.add(dupMap.get(plcyCode));
				} else {
					dupMap.put(plcyCode, loanVO);
				}
				Float reqLoanAmount = loanVO.getLoanRequestAmount();
				Float policyAmount = loanVO.getPolicyAmount();
				boolean amount = reqLoanAmount > (0.4 * assuredAmount);
				if (plcyTyp.equals("FST")
						&& (reqLoanAmount > (0.4 * assuredAmount))) {
					calculateNetPaymentEligible(loanVO, sanctionDate,
							assuredAmount);
					elgList.add(loanVO);
				}
				if (plcyTyp.equals("FST")
						&& reqLoanAmount > (0.6 * assuredAmount)) {
					calculateNetPaymentNonEligible(loanVO, reqLoanAmount);
					nonElgList.add(loanVO);
				}
				if (plcyTyp.equals("NRS")
						&& reqLoanAmount > (0.6 * assuredAmount)) {
					calculateNetPaymentEligible(loanVO, sanctionDate,
							assuredAmount);
					elgList.add(loanVO);
				}
				if (plcyTyp.equals("NRS")
						&& reqLoanAmount > (0.6 * assuredAmount)
						&& reqLoanAmount < (0.7 * policyAmount)) {
					calculateNetPaymentEligible(loanVO, sanctionDate,
							assuredAmount);
					elgList.add(loanVO);

				}
				if (plcyTyp.equals("NRS")
						&& reqLoanAmount > (0.6 * assuredAmount)
						&& reqLoanAmount > (0.7 * policyAmount)) {
					calculateNetPaymentNonEligible(loanVO, reqLoanAmount);
					nonElgList.add(loanVO);
				}
				if (reqLoanAmount > assuredAmount) {
					inavlidList.add(loanVO);
				}
			}
			innerMap1.put("ELG", elgList);
			innerMap1.put("NELG", nonElgList);
			innerMap2.put("DUP", dupList);
			innerMap2.put("INV", inavlidList);
			mainMap.put(1, innerMap1);
			mainMap.put(2, innerMap2);
		} catch (ParseException e) {
			throw new LoanTrustException("Invalid date format");
		} catch (Exception e) {
			throw new LoanTrustException(e.getMessage());
		}
		return mainMap;
	}
	private void calculateNetPaymentEligible(LoanTrustVO loanVO,
			String sanctionDate, Float assuredAmount) {
		int loanPeriod = 0;
		Date snctionDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		try {
			snctionDate = sdf.parse(sanctionDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar c1 = Calendar.getInstance();
		c1.setTime(snctionDate);
		Calendar c2 = Calendar.getInstance();
		c2.setTime(loanVO.getEndDate());
		int years = c2.get(Calendar.YEAR) - c1.get(Calendar.YEAR);
		int months = c2.get(Calendar.MONTH) - c1.get(Calendar.MONTH);
		int dateDiff = c2.get(Calendar.DATE) - c1.get(Calendar.DATE);
		if (dateDiff < 0) {
			loanPeriod = ((years * 12) + (months)) - 1;
		} else {
			loanPeriod = (years * 12) + months;
		}
		float interestAmount = (float) (loanVO.getPolicyAmount() * 1.2 * loanPeriod)
				/ (loanVO.getPeriod());
		float calculateAssuredAmount = (assuredAmount / (loanVO.getPeriod()));
		float netPaymentValue = interestAmount + calculateAssuredAmount;
		loanVO.setNetPaymentValue(netPaymentValue);
	}
	private void calculateNetPaymentNonEligible(LoanTrustVO loanVO,
			Float requestLoanAmount) {
		loanVO.setNetPaymentValue(requestLoanAmount);
	}
}

class LoanTrustVO {
	private String policyNumber;
	private String panNumber;
	private Date startDate;
	private Integer period;
	private float loanRequestAmount;
	private float policyAmount;
	private Date endDate;
	private float netPaymentValue;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Integer getPeriod() {
		return period;
	}

	public void setPeriod(Integer period) {
		this.period = period;
	}

	public float getLoanRequestAmount() {
		return loanRequestAmount;
	}

	public void setLoanRequestAmount(float loanRequestAmount) {
		this.loanRequestAmount = loanRequestAmount;
	}

	public float getPolicyAmount() {
		return policyAmount;
	}

	public void setPolicyAmount(float policyAmount) {
		this.policyAmount = policyAmount;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public float getNetPaymentValue() {
		return netPaymentValue;
	}

	public void setNetPaymentValue(float netPaymentValue) {
		this.netPaymentValue = netPaymentValue;
	}

	@Override
	public String toString() {
		return "LoanTrustVO [policyNumber=" + policyNumber + ", panNumber="
				+ panNumber + ", startDate=" + startDate + ", period=" + period
				+ ", loanRequestAmount=" + loanRequestAmount
				+ ", policyAmount=" + policyAmount + ", endDate=" + endDate
				+ ", netPaymentValue=" + netPaymentValue + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + Float.floatToIntBits(loanRequestAmount);
		result = prime * result + Float.floatToIntBits(netPaymentValue);
		result = prime * result
				+ ((panNumber == null) ? 0 : panNumber.hashCode());
		result = prime * result + ((period == null) ? 0 : period.hashCode());
		result = prime * result + Float.floatToIntBits(policyAmount);
		result = prime * result
				+ ((policyNumber == null) ? 0 : policyNumber.hashCode());
		result = prime * result
				+ ((startDate == null) ? 0 : startDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoanTrustVO other = (LoanTrustVO) obj;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (Float.floatToIntBits(loanRequestAmount) != Float
				.floatToIntBits(other.loanRequestAmount))
			return false;
		if (Float.floatToIntBits(netPaymentValue) != Float
				.floatToIntBits(other.netPaymentValue))
			return false;
		if (panNumber == null) {
			if (other.panNumber != null)
				return false;
		} else if (!panNumber.equals(other.panNumber))
			return false;
		if (period == null) {
			if (other.period != null)
				return false;
		} else if (!period.equals(other.period))
			return false;
		if (Float.floatToIntBits(policyAmount) != Float
				.floatToIntBits(other.policyAmount))
			return false;
		if (policyNumber == null) {
			if (other.policyNumber != null)
				return false;
		} else if (!policyNumber.equals(other.policyNumber))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		return true;
	}

}

class LoanTrustException extends Exception {

	private static final long serialVersionUID = 1L;

	public LoanTrustException(String message) {
		super(message);
	}

	public LoanTrustException(Throwable throwable) {
		super(throwable);
	}

	public LoanTrustException(String message, Throwable throwable) {
		super(message, throwable);
	}
}
