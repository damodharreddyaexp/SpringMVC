package com.cts.hospitalmanagement.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cts.hospitalmanagement.constants.SQLConstants;
import com.cts.hospitalmanagement.exception.InvalidDataException;
import com.cts.hospitalmanagement.exception.InvalidPatientException;
import com.cts.hospitalmanagement.pojo.PatientVO;


@Repository
public class PatientManagementDAO {


	private JdbcTemplate jdbcTemplate;

	/**
	 * @param jdbcTemplate
	 */
	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * @param employeeId
	 * @param transferLocation
	 * @throws EmployeeManagementException
	 */
	public void addPatientDetails(PatientVO patientVO)
	{
			jdbcTemplate.update(SQLConstants.ADD_PATIENT_DETAILS,
				patientVO.getPatientID(), patientVO.getTestName(),
				patientVO.getTestCost(), patientVO.getTestDate());
	}
	
	public boolean validPatient(int patientID) throws InvalidDataException
	{
		boolean isValid = true;
		int patient = jdbcTemplate.queryForObject(SQLConstants.GET_PATIENT_RECORD,Integer.class,patientID);
		if(patient == 0)
		{
			isValid = false;
			try {
				throw new InvalidPatientException("Invalid Patient ID");
			} catch (InvalidPatientException e) {
				e.printStackTrace();
			}
		}
		return isValid; 
	}
	
}
