/**
 *
 */
package com.cts.hospitalmanagement.exception;

/**
 * @author 448682
 *
 */
public class InvalidDataException extends Exception {

	private static final long serialVersionUID = 6129612846468843103L;

	/**
	 * @param message
	 */
	public InvalidDataException(String message) {
		super(message);

}
}
