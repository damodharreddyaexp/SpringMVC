package com.cts.hospitalmanagement.exception;

public class InvalidPatientException extends Exception {

	public InvalidPatientException(String string) {
		// TODO Auto-generated constructor stub
	}

}
