/**
 *
 */
package com.cts.hospitalmanagement.exception;

/**
 * @author 448682
 *
 */
public class NoDataFoundException extends Exception {

	private static final long serialVersionUID = 6129612846468843103L;

	/**
	 * @param message
	 */
	public NoDataFoundException(String message) {
		super(message);

}
}
