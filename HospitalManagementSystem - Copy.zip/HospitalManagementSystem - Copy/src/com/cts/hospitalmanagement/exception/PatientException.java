package com.cts.hospitalmanagement.exception;

public class PatientException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6291182935576508348L;

	public PatientException(String exc) {
		// TODO Auto-generated constructor stub
		super(exc);
	}

	public PatientException(Throwable throwable) {
		// TODO Auto-generated constructor stub
		super(throwable);
	}

	public PatientException(String exc, Throwable throwable) {
		// TODO Auto-generated constructor stub
		super(exc, throwable);
	}
}
