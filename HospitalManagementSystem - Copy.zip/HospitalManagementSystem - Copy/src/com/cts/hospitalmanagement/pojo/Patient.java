package com.cts.hospitalmanagement.pojo;

import java.util.Date;


public class Patient {

		private String name;
		private String gender;
		private Date admissionDate;
		private Date dischargeDate;
		private int bill;
		private String patientPategory;
		private String physicianCategory;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public Date getAdmissionDate() {
			return admissionDate;
		}

		public void setAdmissionDate(Date admissionDate) {
			this.admissionDate = admissionDate;
		}

		public Date getDischargeDate() {
			return dischargeDate;
		}

		public void setDischargeDate(Date dischargeDate) {
			this.dischargeDate = dischargeDate;
		}

		public int getBill() {
			return bill;
		}

		public void setBill(int bill) {
			this.bill = bill;
		}

		public String getPatientPategory() {
			return patientPategory;
		}

		public void setPatientCategory(String patientPategory) {
			this.patientPategory = patientPategory;
		}

		public String getPhysicianCategory() {
			return physicianCategory;
		}

		public void setPhysicianCategory(String physicianCategory) {
			this.physicianCategory = physicianCategory;
		}

		@Override
		public String toString() {
			return "patient [name=" + name + ", gender=" + gender + ", admissionDate=" + admissionDate
					+ ", dischargeDate=" + dischargeDate + ", bill=" + bill + ", patientPategory=" + patientPategory
					+ ", physicianCategory=" + physicianCategory + "]";
		}

		@Override
		public boolean equals(Object obj) {

			return super.equals(obj);
		}

	}
