package com.cts.hospitalmanagement.pojo;

import java.util.Date;

public class PatientVO {
	int patientID;
	String testName;
	float testCost;
	Date testDate;
	public int getPatientID() {
		return patientID;
	}
	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public float getTestCost() {
		return testCost;
	}
	public void setTestCost(float testCost) {
		this.testCost = testCost;
	}
	public Date getTestDate() {
		return testDate;
	}
	public void setTestDate(Date testDate) {
		this.testDate = testDate;
	}

}
