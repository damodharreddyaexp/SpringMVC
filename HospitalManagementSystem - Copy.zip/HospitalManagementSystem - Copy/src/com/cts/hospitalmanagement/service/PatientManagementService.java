package com.cts.hospitalmanagement.service;

import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.cts.hospitalmanagement.bo.PatientManagementBO;
import com.cts.hospitalmanagement.exception.InvalidDataException;
import com.cts.hospitalmanagement.exception.NoDataFoundException;
import com.cts.hospitalmanagement.pojo.PatientVO;


@Service
public class PatientManagementService {

	@Autowired
	private PatientManagementBO patientManagementBO;

	@Autowired
	MessageSource messageSource;
	
	/**
	 * @param employeeId
	 * @param transferLocation
	 * @throws EmployeeManagementException
	 */
	public void addPatientDetails(int patientId, String testName)
	{
		PatientVO patientVO = new PatientVO();
		patientVO.setPatientID(patientId);
		patientVO.setTestName(testName);
		patientVO.setTestDate(new Date());
		try {
			patientManagementBO.addPatientDetails(patientVO);
		} catch (NoDataFoundException e) {
			e.printStackTrace();
		} catch (InvalidDataException e) {
			e.printStackTrace();
		}
	}
	
	public String getBenefits(String policyName)
	{
		String benefits = messageSource.getMessage(policyName,null,Locale.US);
		return benefits;
	}
	
}
